package com.example.flagpicker;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author SRINIVASARAON
 *
 */

@SpringBootApplication
public class FlagPickerApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(FlagPickerApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

	}
}

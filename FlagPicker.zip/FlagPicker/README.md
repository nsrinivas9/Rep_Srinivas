## FlagPicker 
This application enables to list the countries of a Continent and flags of respective countries.
 

## Getting Started
As we don't have any external DB here, you can run this application as SpringBoot App.

## Prerequisites
Java 8, 
Maven

##Scope of project
Implemented using SpringBoot, Rest API, Swagger, Actuator. 
In this application we are using JSON file as Data Source.

## Next scope of project
Implementing security using JWT
Implementing MicroServices
Implementing API Versioning